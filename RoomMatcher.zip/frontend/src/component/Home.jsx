import { Navbar } from "./Navbar";

export function Home(){
  return(
    <Navbar />
  )
}