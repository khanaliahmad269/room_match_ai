import { useState } from "react";
import { Navbar } from "./Navbar";
import axios from "axios";
import { useAuth } from "../state/AuthContext";
import LoaderDemo from "./Loader";

export default function Dashboard() {
  const { auth, setAuth } = useAuth();
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [results, setResults] = useState([]); // ✅ store search results
  const handleSearch = async () => {
    try {
      const requestData = {
        query: search,
      };
      setLoading(true);
      const res = await axios.post("http://127.0.0.1:8000/search", requestData);

      console.log("✅ Server Response:", res.data);
      setResults(res.data.results || []); // ✅ save results
      setLoading(false);
    } catch (err) {
      console.error("❌ Error sending search request:", err);
      alert("Failed to send search request.");
      setLoading(false);
    }
  };

  return (
    <>
     {loading ? <LoaderDemo/> : null}
      <Navbar />
      <div
        className="container-fluid min-vh-100 p-4"
        style={{
          background: "linear-gradient(135deg, #f9fafc 0%, #e8f0fe 100%)",
        }}
      >
        {/* Page Header */}
        <div className="text-center mb-5">
          <h2
            className="fw-bold"
            style={{
              background: "linear-gradient(90deg, #6a11cb, #2575fc)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            <i className="bi bi-speedometer2 me-2"></i>
            Roommate Dashboard
          </h2>
          <p className="text-muted">Set your preferences & find your match 🚀</p>
        </div>

        <div className="row g-4">
          {/* Panel */}
          <div className="col-md-12">
            <div
              className="card border-0 shadow-lg rounded-4"
            >
              <div className="card-body">
                <div className="input-group mb-3">
                  <span
                    className="input-group-text border-0"
                    style={{
                      background: "linear-gradient(135deg, #6a11cb, #2575fc)",
                      color: "white",
                    }}
                  >
                    <i className="bi bi-search"></i>
                  </span>
                  <input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="form-control rounded-end-pill"
                    placeholder="Search..."
                  />
                </div>
                <button className="btn btn-primary mx-auto d-block" style={{ background: "linear-gradient(135deg, #6a11cb, #2575fc)" }} onClick={handleSearch}>Search</button>
                {/* Results Section */}
                <div className="mt-4">
                  {results.length > 0 && (
                    <div>
                      <h5 className="fw-bold text-primary">Search Results:</h5>
                      <div className="list-group mt-3">
                        {results.map((item, idx) => (
                          <div
                            key={idx}
                            className="list-group-item list-group-item-action shadow-sm rounded-3 mb-3"
                          >
                            <h6 className="fw-bold">
                              🏠 {item.profile.area}, {item.profile.city}
                            </h6>
                            <p className="mb-1 text-muted">
                              {item.profile.raw_profile_text}
                            </p>
                            <p className="mb-1">
                              <strong>Budget:</strong> PKR{" "}
                              {item.profile.budget_PKR}
                            </p>
                            <p className="mb-1">
                              <strong>Score:</strong> {item.score}
                            </p>
                            <p className="small text-success">
                              ✅ {item.similarity}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  {results.length === 0 && !loading && (
                    <p className="text-muted text-center mt-4">
                      No results yet. Try searching above 👆
                    </p>
                  )}
              </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
